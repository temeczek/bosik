import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import {
  BriefcaseBusiness, Check, ChevronRight, CircleUserRound, Clock3, Coins, Hammer,
  Inbox, LogIn, LogOut, MapPin, MessageCircle, Plus, Search, Send, SlidersHorizontal,
  Star, UserRound, WalletCards, X,
} from "lucide-react";
import { lovable } from "@/integrations/lovable";
import { supabase } from "@/integrations/supabase/client";
import type { Database } from "@/integrations/supabase/types";
import { Button } from "@/components/ui/button";

type Profile = Database["public"]["Tables"]["profiles"]["Row"];
type Job = Database["public"]["Tables"]["jobs"]["Row"];
type Offer = Database["public"]["Tables"]["offers"]["Row"];
type Message = Database["public"]["Tables"]["messages"]["Row"];
type Review = Database["public"]["Tables"]["reviews"]["Row"];
type SessionUser = { id: string; email: string | undefined };
type View = "market" | "my-jobs" | "offers" | "messages" | "profile";

const categories = ["Remont i budowa", "Elektryka", "Hydraulika", "Sprzątanie", "Ogród", "Transport", "Montaż i naprawy", "Inne"];
const money = new Intl.NumberFormat("pl-PL", { style: "currency", currency: "PLN", maximumFractionDigits: 0 });
const date = new Intl.DateTimeFormat("pl-PL", { day: "numeric", month: "short" });

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: React.ReactNode }) {
  return <div className="fixed inset-0 z-50 grid place-items-end bg-overlay p-0 sm:place-items-center sm:p-5" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
    <section className="max-h-[94vh] w-full overflow-y-auto rounded-t-xl bg-background p-5 shadow-dialog sm:max-w-xl sm:rounded-lg sm:p-7">
      <div className="mb-6 flex items-center justify-between"><h2 className="text-xl font-bold">{title}</h2><Button variant="ghost" size="icon" aria-label="Zamknij" onClick={onClose}><X className="size-5" /></Button></div>
      {children}
    </section>
  </div>;
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return <label className="grid gap-2 text-sm font-semibold text-foreground">{label}{children}</label>;
}

function AuthModal({ onClose }: { onClose: () => void }) {
  const [mode, setMode] = useState<"login" | "signup" | "forgot">("login");
  const [busy, setBusy] = useState(false); const [notice, setNotice] = useState("");
  async function submit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); setBusy(true); setNotice(""); const form = new FormData(e.currentTarget);
    const email = String(form.get("email") ?? "").trim(); const password = String(form.get("password") ?? "");
    if (!email.includes("@")) { setNotice("Podaj poprawny adres e-mail."); setBusy(false); return; }
    if (mode === "forgot") {
      const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: `${window.location.origin}/reset-password` });
      setNotice(error ? error.message : "Wysłaliśmy link do ustawienia nowego hasła."); setBusy(false); return;
    }
    if (password.length < 8) { setNotice("Hasło musi mieć co najmniej 8 znaków."); setBusy(false); return; }
    if (mode === "signup") {
      const role = String(form.get("role") ?? "client"); const displayName = String(form.get("name") ?? "").trim();
      if (displayName.length < 2) { setNotice("Podaj nazwę wyświetlaną."); setBusy(false); return; }
      const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin, data: { display_name: displayName, role } } });
      setNotice(error ? error.message : data.session ? "Konto utworzone." : "Sprawdź e-mail i potwierdź rejestrację.");
    } else {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (!error) onClose(); else setNotice(error.message);
    }
    setBusy(false);
  }
  async function google() {
    setBusy(true); const result = await lovable.auth.signInWithOAuth("google", { redirect_uri: window.location.origin, extraParams: { prompt: "select_account" } });
    if (result.error) setNotice(result.error.message); else if (!result.redirected) onClose(); setBusy(false);
  }
  return <Modal title={mode === "signup" ? "Załóż konto" : mode === "forgot" ? "Odzyskaj hasło" : "Witaj ponownie"} onClose={onClose}>
    <div className="grid gap-4">
      {mode !== "forgot" && <Button variant="outline" onClick={google} disabled={busy}><span className="text-base font-bold">G</span> Kontynuuj z Google</Button>}
      {mode !== "forgot" && <div className="flex items-center gap-3 text-xs text-muted-foreground"><span className="h-px flex-1 bg-border" />lub e-mail<span className="h-px flex-1 bg-border" /></div>}
      <form className="grid gap-4" onSubmit={submit}>
        {mode === "signup" && <><Field label="Nazwa wyświetlana"><input name="name" maxLength={80} required placeholder="Np. Tomasz Kowalski" /></Field><Field label="Jak chcesz korzystać?"><select name="role"><option value="client">Szukam wykonawcy</option><option value="contractor">Realizuję zlecenia</option></select></Field></>}
        <Field label="E-mail"><input name="email" type="email" autoComplete="email" required placeholder="ty@email.pl" /></Field>
        {mode !== "forgot" && <Field label="Hasło"><input name="password" type="password" autoComplete={mode === "signup" ? "new-password" : "current-password"} minLength={8} required placeholder="Minimum 8 znaków" /></Field>}
        {notice && <p className="rounded-md bg-muted p-3 text-sm">{notice}</p>}
        <Button type="submit" disabled={busy}>{busy ? "Chwila…" : mode === "signup" ? "Utwórz konto" : mode === "forgot" ? "Wyślij link" : "Zaloguj się"}<ChevronRight className="size-4" /></Button>
      </form>
      <div className="flex flex-wrap justify-between gap-2 text-sm">
        <Button variant="ghost" size="sm" onClick={() => setMode(mode === "signup" ? "login" : "signup")}>{mode === "signup" ? "Mam już konto" : "Załóż konto"}</Button>
        {mode !== "forgot" && <Button variant="ghost" size="sm" onClick={() => setMode("forgot")}>Nie pamiętam hasła</Button>}
      </div>
    </div>
  </Modal>;
}

function JobCard({ job, onOpen }: { job: Job; onOpen: () => void }) {
  const budget = job.budget_min != null && job.budget_max != null ? `${money.format(job.budget_min)}–${money.format(job.budget_max)}` : job.budget_max != null ? `do ${money.format(job.budget_max)}` : "Do ustalenia";
  return <article className="job-card">
    <div className="flex items-start justify-between gap-4"><span className="category-mark">{job.category}</span><span className="status-dot">{job.status === "open" ? "Aktywne" : job.status === "assigned" ? "W realizacji" : job.status === "completed" ? "Zakończone" : "Anulowane"}</span></div>
    <button type="button" className="mt-4 text-left" onClick={onOpen}><h3 className="text-lg font-bold leading-snug hover:text-primary">{job.title}</h3></button>
    <p className="mt-2 line-clamp-2 text-sm leading-6 text-muted-foreground">{job.description}</p>
    <div className="mt-5 flex flex-wrap gap-x-5 gap-y-2 text-sm"><span className="inline-flex items-center gap-1.5"><MapPin className="size-4 text-primary" />{job.location}</span><span className="inline-flex items-center gap-1.5"><WalletCards className="size-4 text-primary" />{budget}</span></div>
    <div className="mt-5 flex items-center justify-between border-t border-border pt-4 text-xs text-muted-foreground"><span>Dodano {date.format(new Date(job.created_at))}</span><Button variant="ghost" size="sm" onClick={onOpen}>Zobacz <ChevronRight className="size-4" /></Button></div>
  </article>;
}

export function ZlecenkaApp() {
  const [user, setUser] = useState<SessionUser | null>(null); const [profile, setProfile] = useState<Profile | null>(null);
  const [jobs, setJobs] = useState<Job[]>([]); const [offers, setOffers] = useState<Offer[]>([]); const [messages, setMessages] = useState<Message[]>([]); const [reviews, setReviews] = useState<Review[]>([]);
  const [view, setView] = useState<View>("market"); const [authOpen, setAuthOpen] = useState(false); const [createOpen, setCreateOpen] = useState(false);
  const [activeJob, setActiveJob] = useState<Job | null>(null); const [activeOffer, setActiveOffer] = useState<Offer | null>(null); const [query, setQuery] = useState(""); const [category, setCategory] = useState("Wszystkie");
  const [busy, setBusy] = useState(false); const [notice, setNotice] = useState("");

  const load = useCallback(async () => {
    const [{ data: openJobs }, { data: publicReviews }] = await Promise.all([supabase.from("jobs").select("*").order("created_at", { ascending: false }), supabase.from("reviews").select("*").order("created_at", { ascending: false })]); setJobs(openJobs ?? []); setReviews(publicReviews ?? []);
    const { data: auth } = await supabase.auth.getUser(); const current = auth.user ? { id: auth.user.id, email: auth.user.email } : null; setUser(current);
    if (!current) { setProfile(null); setOffers([]); setMessages([]); return; }
    const [{ data: p }, { data: o }, { data: m }] = await Promise.all([
      supabase.from("profiles").select("*").eq("id", current.id).single(),
      supabase.from("offers").select("*").order("created_at", { ascending: false }),
      supabase.from("messages").select("*").order("created_at"),
    ]); setProfile(p); setOffers(o ?? []); setMessages(m ?? []);
  }, []);
  useEffect(() => { void load(); const { data } = supabase.auth.onAuthStateChange((event) => { if (["SIGNED_IN", "SIGNED_OUT", "USER_UPDATED"].includes(event)) void load(); }); return () => data.subscription.unsubscribe(); }, [load]);
  useEffect(() => { if (!user) return; const channel = supabase.channel(`messages-${user.id}`).on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => void load()).subscribe(); return () => { void supabase.removeChannel(channel); }; }, [user, load]);

  const filtered = useMemo(() => jobs.filter(j => j.status === "open" && (category === "Wszystkie" || j.category === category) && `${j.title} ${j.description} ${j.location}`.toLowerCase().includes(query.toLowerCase())), [jobs, query, category]);
  const myJobs = jobs.filter(j => j.client_id === user?.id); const myOffers = offers.filter(o => o.contractor_id === user?.id);
  const inboxOffers = offers.filter(o => myJobs.some(j => j.id === o.job_id)); const visibleOffers = profile?.role === "contractor" ? myOffers : inboxOffers;

  function requireAuth(action: () => void) { if (!user) setAuthOpen(true); else action(); }
  async function createJob(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!user) return; setBusy(true); setNotice(""); const f = new FormData(e.currentTarget);
    const payload = { client_id: user.id, title: String(f.get("title") ?? "").trim(), category: String(f.get("category") ?? ""), description: String(f.get("description") ?? "").trim(), location: String(f.get("location") ?? "").trim(), due_date: String(f.get("due_date") ?? "") || null, budget_min: Number(f.get("budget_min")) || null, budget_max: Number(f.get("budget_max")) || null };
    if (payload.title.length < 5 || payload.description.length < 20 || payload.location.length < 2) { setNotice("Uzupełnij tytuł, lokalizację i opis (minimum 20 znaków)."); setBusy(false); return; }
    const files = f.getAll("images").filter((x): x is File => x instanceof File && x.size > 0); const paths: string[] = [];
    for (const file of files.slice(0, 5)) { if (file.size > 8_000_000 || !file.type.startsWith("image/")) continue; const path = `${user.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9.-]/g, "-")}`; const { error } = await supabase.storage.from("job-images").upload(path, file); if (!error) paths.push(path); }
    const { error } = await supabase.from("jobs").insert({ ...payload, images: paths }); setBusy(false);
    if (error) setNotice(error.message); else { setCreateOpen(false); setView("my-jobs"); await load(); }
  }
  async function submitOffer(e: FormEvent<HTMLFormElement>) {
    e.preventDefault(); if (!user || !activeJob) return; setBusy(true); setNotice(""); const f = new FormData(e.currentTarget);
    const { error } = await supabase.from("offers").insert({ job_id: activeJob.id, contractor_id: user.id, price: Number(f.get("price")), completion_days: Number(f.get("days")), message: String(f.get("message") ?? "").trim() });
    setBusy(false); if (error) setNotice(error.message.includes("duplicate") ? "Oferta do tego zlecenia została już wysłana." : error.message); else { setNotice("Oferta wysłana. Pobrano 10 punktów."); await load(); }
  }
  async function chooseOffer(offer: Offer) { if (!activeJob) return; setBusy(true); const { error } = await supabase.from("jobs").update({ selected_offer_id: offer.id }).eq("id", activeJob.id); setBusy(false); if (error) setNotice(error.message); else { setActiveJob({ ...activeJob, selected_offer_id: offer.id, status: "assigned" }); await load(); } }
  async function completeJob(job: Job) { setBusy(true); const { error } = await supabase.from("jobs").update({ status: "completed" }).eq("id", job.id); setBusy(false); if (error) setNotice(error.message); else { setActiveJob({ ...job, status: "completed" }); await load(); } }
  async function sendMessage(e: FormEvent<HTMLFormElement>) { e.preventDefault(); if (!user || !activeOffer) return; const f = new FormData(e.currentTarget); const body = String(f.get("body") ?? "").trim(); if (!body) return; const { error } = await supabase.from("messages").insert({ offer_id: activeOffer.id, sender_id: user.id, body }); if (!error) { e.currentTarget.reset(); await load(); } }
  async function saveProfile(e: FormEvent<HTMLFormElement>) { e.preventDefault(); if (!user) return; setBusy(true); const f = new FormData(e.currentTarget); const { error } = await supabase.from("profiles").update({ display_name: String(f.get("name") ?? "").trim(), role: String(f.get("role")) as "client" | "contractor", location: String(f.get("location") ?? "").trim(), bio: String(f.get("bio") ?? "").trim(), specialties: String(f.get("specialties") ?? "").split(",").map(s => s.trim()).filter(Boolean).slice(0, 10) }).eq("id", user.id); setBusy(false); setNotice(error ? error.message : "Profil zapisany."); await load(); }
  async function submitReview(e: FormEvent<HTMLFormElement>) { e.preventDefault(); if (!user || !activeJob) return; const accepted = offers.find(o => o.id === activeJob.selected_offer_id); if (!accepted) return; const recipientId = activeJob.client_id === user.id ? accepted.contractor_id : activeJob.client_id; const f = new FormData(e.currentTarget); const rating = Number(f.get("rating")); const comment = String(f.get("comment") ?? "").trim(); if (rating < 1 || rating > 5) { setNotice("Wybierz ocenę od 1 do 5."); return; } setBusy(true); const { error } = await supabase.from("reviews").insert({ job_id: activeJob.id, author_id: user.id, recipient_id: recipientId, rating, comment: comment || null }); setBusy(false); setNotice(error ? (error.message.includes("duplicate") ? "To zlecenie zostało już przez Ciebie ocenione." : error.message) : "Dziękujemy za opinię."); await load(); }
  async function signOut() { await supabase.auth.signOut(); setView("market"); }

  const nav = [{ id: "market", label: "Zlecenia", icon: Search }, ...(user ? [{ id: "my-jobs", label: "Moje zlecenia", icon: BriefcaseBusiness }, { id: "offers", label: "Oferty", icon: Inbox }, { id: "messages", label: "Wiadomości", icon: MessageCircle }, { id: "profile", label: "Profil", icon: UserRound }] : [])] as { id: View; label: string; icon: typeof Search }[];
  return <div className="min-h-screen bg-background">
    <header className="sticky top-0 z-30 border-b border-border bg-background/95 backdrop-blur"><div className="mx-auto flex h-16 max-w-7xl items-center gap-5 px-4 sm:px-6"><button className="flex items-center gap-2" onClick={() => setView("market")}><span className="grid size-9 place-items-center rounded-md bg-primary text-primary-foreground"><Hammer className="size-5" /></span><span className="text-xl font-black">Zlecenka</span></button><nav className="hidden flex-1 items-center gap-1 md:flex">{nav.map(n => <Button key={n.id} variant={view === n.id ? "secondary" : "ghost"} size="sm" onClick={() => setView(n.id)}><n.icon className="size-4" />{n.label}</Button>)}</nav><div className="ml-auto flex items-center gap-2">{profile?.role === "contractor" && <span className="hidden items-center gap-1 rounded-md bg-coin px-3 py-2 text-sm font-bold text-coin-foreground sm:inline-flex"><Coins className="size-4" />{profile.points}</span>}<Button onClick={() => requireAuth(() => setCreateOpen(true))}><Plus className="size-4" /><span className="hidden sm:inline">Dodaj zlecenie</span></Button>{user ? <Button variant="ghost" size="icon" aria-label="Wyloguj" onClick={signOut}><LogOut className="size-5" /></Button> : <Button variant="outline" onClick={() => setAuthOpen(true)}><LogIn className="size-4" />Zaloguj</Button>}</div></div></header>
    <main>
      {view === "market" && <><section className="market-head"><div className="mx-auto max-w-7xl px-4 py-10 sm:px-6 sm:py-14"><p className="mb-3 text-sm font-bold uppercase text-primary">Zlecenia z Twojej okolicy</p><h1 className="max-w-2xl text-3xl font-black leading-tight sm:text-5xl">Znajdź konkretną pracę. Bez pośredników.</h1><p className="mt-4 max-w-xl text-muted-foreground">Przeglądaj aktualne zlecenia, składaj oferty i ustalaj szczegóły bezpośrednio z klientem.</p><div className="mt-8 flex max-w-3xl flex-col gap-3 sm:flex-row"><label className="search-box flex-1"><Search className="size-5" /><input value={query} onChange={e => setQuery(e.target.value)} placeholder="Czego lub gdzie szukasz?" /></label><Button onClick={() => requireAuth(() => setCreateOpen(true))}><Plus className="size-4" />Zleć pracę</Button></div></div></section><section className="mx-auto max-w-7xl px-4 py-8 sm:px-6"><div className="mb-6 flex items-center gap-3 overflow-x-auto pb-2"><SlidersHorizontal className="size-4 shrink-0 text-muted-foreground" />{["Wszystkie", ...categories].map(c => <Button key={c} variant={category === c ? "default" : "outline"} size="sm" onClick={() => setCategory(c)}>{c}</Button>)}</div>{filtered.length ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{filtered.map(j => <JobCard key={j.id} job={j} onOpen={() => setActiveJob(j)} />)}</div> : <Empty icon={BriefcaseBusiness} title="Brak pasujących zleceń" text="Zmień wyszukiwanie albo dodaj pierwsze zlecenie w tej okolicy." />}</section></>}
      {view === "my-jobs" && <Page title="Moje zlecenia" action={<Button onClick={() => setCreateOpen(true)}><Plus className="size-4" />Nowe zlecenie</Button>}>{myJobs.length ? <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">{myJobs.map(j => <JobCard key={j.id} job={j} onOpen={() => setActiveJob(j)} />)}</div> : <Empty icon={BriefcaseBusiness} title="Nie masz jeszcze zleceń" text="Opisz, czego potrzebujesz, a wykonawcy prześlą Ci swoje propozycje." />}</Page>}
      {view === "offers" && <Page title={profile?.role === "contractor" ? "Moje oferty" : "Otrzymane oferty"}>{visibleOffers.length ? <div className="grid gap-3">{visibleOffers.map(o => <OfferRow key={o.id} offer={o} job={jobs.find(j => j.id === o.job_id)} onChat={() => { setActiveOffer(o); setView("messages"); }} />)}</div> : <Empty icon={Inbox} title="Tu pojawią się oferty" text={profile?.role === "contractor" ? "Otwórz zlecenie i przedstaw klientowi swoją propozycję." : "Gdy wykonawca odpowie na Twoje zlecenie, zobaczysz go tutaj."} />}</Page>}
      {view === "messages" && <Page title="Wiadomości"><div className="message-layout"><div className="border-r border-border">{visibleOffers.map(o => <button key={o.id} className={`conversation ${activeOffer?.id === o.id ? "bg-muted" : ""}`} onClick={() => setActiveOffer(o)}><MessageCircle className="size-5 text-primary" /><span><b>{jobs.find(j => j.id === o.job_id)?.title ?? "Rozmowa"}</b><small>{o.status === "accepted" ? "Oferta wybrana" : "Oferta w toku"}</small></span></button>)}</div><div className="flex min-h-96 flex-col">{activeOffer ? <><div className="flex-1 space-y-3 p-5">{messages.filter(m => m.offer_id === activeOffer.id).map(m => <div key={m.id} className={`message ${m.sender_id === user?.id ? "message-own" : "message-other"}`}>{m.body}<small>{new Date(m.created_at).toLocaleTimeString("pl-PL", { hour: "2-digit", minute: "2-digit" })}</small></div>)}</div><form className="flex gap-2 border-t border-border p-4" onSubmit={sendMessage}><input name="body" maxLength={2000} required placeholder="Napisz wiadomość…" /><Button size="icon" aria-label="Wyślij"><Send className="size-4" /></Button></form></> : <Empty icon={MessageCircle} title="Wybierz rozmowę" text="Twoje rozmowy z klientami i wykonawcami są prywatne." />}</div></div></Page>}
      {view === "profile" && profile && <Page title="Twój profil"><div className="profile-grid"><form className="panel grid gap-4" onSubmit={saveProfile}><div className="flex items-center gap-4"><div className="avatar">{profile.display_name.slice(0, 1).toUpperCase()}</div><div><h2 className="text-xl font-bold">{profile.display_name}</h2><p className="text-sm text-muted-foreground">{user?.email}</p></div></div><Field label="Nazwa"><input name="name" defaultValue={profile.display_name} minLength={2} maxLength={80} required /></Field><Field label="Rola"><select name="role" defaultValue={profile.role}><option value="client">Klient</option><option value="contractor">Wykonawca</option></select></Field><Field label="Lokalizacja"><input name="location" defaultValue={profile.location ?? ""} maxLength={120} placeholder="Miasto i okolice" /></Field><Field label="Specjalizacje"><input name="specialties" defaultValue={profile.specialties.join(", ")} placeholder="np. elektryka, montaż, pomiary" /></Field><Field label="O mnie"><textarea name="bio" defaultValue={profile.bio ?? ""} maxLength={800} rows={5} placeholder="Napisz krótko o swoim doświadczeniu" /></Field>{notice && <p className="text-sm text-primary">{notice}</p>}<Button disabled={busy}>Zapisz profil</Button></form><aside className="grid content-start gap-4"><div className="stat"><Star className="size-6 text-rating" /><div><b>{profile.rating.toFixed(1)} / 5</b><span>{profile.review_count} opinii</span></div></div><div className="stat"><Coins className="size-6 text-primary" /><div><b>{profile.points} punktów</b><span>Saldo konta wykonawcy</span></div></div>{reviews.filter(r => r.recipient_id === profile.id).map(r => <article key={r.id} className="panel"><div className="flex items-center gap-1 text-rating">{Array.from({ length: r.rating }, (_, i) => <Star key={i} className="size-4 fill-current" />)}</div>{r.comment && <p className="mt-2 text-sm leading-6">{r.comment}</p>}</article>)}</aside></div></Page>}
    </main>
    <nav className="mobile-nav">{nav.map(n => <button key={n.id} onClick={() => setView(n.id)} className={view === n.id ? "text-primary" : "text-muted-foreground"}><n.icon className="size-5" /><span>{n.label}</span></button>)}</nav>
    {authOpen && <AuthModal onClose={() => setAuthOpen(false)} />}
    {createOpen && <Modal title="Dodaj zlecenie" onClose={() => setCreateOpen(false)}><form className="grid gap-4" onSubmit={createJob}><Field label="Tytuł"><input name="title" minLength={5} maxLength={120} required placeholder="Np. montaż lamp w mieszkaniu" /></Field><Field label="Kategoria"><select name="category">{categories.map(c => <option key={c}>{c}</option>)}</select></Field><Field label="Opis"><textarea name="description" minLength={20} maxLength={3000} rows={5} required placeholder="Opisz zakres pracy i ważne szczegóły…" /></Field><div className="grid gap-4 sm:grid-cols-2"><Field label="Lokalizacja"><input name="location" maxLength={120} required placeholder="Warszawa, Mokotów" /></Field><Field label="Termin"><input name="due_date" type="date" /></Field><Field label="Budżet od"><input name="budget_min" type="number" min={0} placeholder="500" /></Field><Field label="Budżet do"><input name="budget_max" type="number" min={0} placeholder="1000" /></Field></div><Field label="Zdjęcia (do 5, maks. 8 MB)"><input name="images" type="file" accept="image/*" multiple /></Field>{notice && <p className="rounded-md bg-muted p-3 text-sm">{notice}</p>}<Button disabled={busy}>{busy ? "Publikuję…" : "Opublikuj zlecenie"}</Button></form></Modal>}
    {activeJob && <Modal title={activeJob.title} onClose={() => { setActiveJob(null); setNotice(""); }}><JobDetails job={activeJob} user={user} profile={profile} offers={offers.filter(o => o.job_id === activeJob.id)} reviews={reviews.filter(r => r.job_id === activeJob.id)} notice={notice} busy={busy} onOffer={submitOffer} onChoose={chooseOffer} onChat={(o) => { setActiveOffer(o); setActiveJob(null); setView("messages"); }} onComplete={() => completeJob(activeJob)} onReview={submitReview} /></Modal>}
  </div>;
}

function Page({ title, action, children }: { title: string; action?: React.ReactNode; children: React.ReactNode }) { return <section className="mx-auto max-w-7xl px-4 py-8 pb-24 sm:px-6 sm:py-12"><div className="mb-7 flex items-center justify-between gap-4"><h1 className="text-3xl font-black">{title}</h1>{action}</div>{children}</section>; }
function Empty({ icon: Icon, title, text }: { icon: typeof BriefcaseBusiness; title: string; text: string }) { return <div className="empty"><Icon className="size-8 text-primary" /><h3 className="mt-4 text-lg font-bold">{title}</h3><p className="mt-1 max-w-md text-sm text-muted-foreground">{text}</p></div>; }
function OfferRow({ offer, job, onChat }: { offer: Offer; job: Job | undefined; onChat: () => void }) { return <article className="panel flex flex-col gap-4 sm:flex-row sm:items-center"><div className="flex-1"><span className="text-xs font-bold uppercase text-primary">{offer.status === "accepted" ? "Wybrana" : offer.status === "rejected" ? "Niewybrana" : "Oczekuje"}</span><h3 className="mt-1 font-bold">{job?.title ?? "Zlecenie"}</h3><p className="mt-1 line-clamp-1 text-sm text-muted-foreground">{offer.message}</p></div><div className="text-left sm:text-right"><b className="text-lg">{money.format(offer.price)}</b><p className="text-xs text-muted-foreground">{offer.completion_days} dni</p></div><Button variant="outline" onClick={onChat}><MessageCircle className="size-4" />Rozmowa</Button></article>; }
function JobDetails({ job, user, profile, offers, reviews, notice, busy, onOffer, onChoose, onChat, onComplete, onReview }: { job: Job; user: SessionUser | null; profile: Profile | null; offers: Offer[]; reviews: Review[]; notice: string; busy: boolean; onOffer: (e: FormEvent<HTMLFormElement>) => void; onChoose: (o: Offer) => void; onChat: (o: Offer) => void; onComplete: () => void; onReview: (e: FormEvent<HTMLFormElement>) => void }) {
  const own = job.client_id === user?.id; const already = offers.some(o => o.contractor_id === user?.id);
  const canReview = Boolean(user && job.status === "completed" && job.selected_offer_id && (own || offers.some(o => o.id === job.selected_offer_id && o.contractor_id === user.id)) && !reviews.some(r => r.author_id === user.id));
  return <div className="grid gap-6"><div className="flex flex-wrap gap-4 text-sm"><span className="inline-flex items-center gap-1"><MapPin className="size-4 text-primary" />{job.location}</span>{job.due_date && <span className="inline-flex items-center gap-1"><Clock3 className="size-4 text-primary" />do {date.format(new Date(job.due_date))}</span>}</div><p className="whitespace-pre-line leading-7 text-muted-foreground">{job.description}</p>{own && <div className="grid gap-3"><h3 className="font-bold">Oferty wykonawców ({offers.length})</h3>{offers.map(o => <div className="offer-box" key={o.id}><div><b>{money.format(o.price)} · {o.completion_days} dni</b><p className="mt-1 text-sm text-muted-foreground">{o.message}</p></div><div className="flex gap-2"><Button variant="outline" size="sm" onClick={() => onChat(o)} aria-label="Otwórz rozmowę"><MessageCircle className="size-4" /></Button>{job.status === "open" && <Button size="sm" onClick={() => onChoose(o)} disabled={busy}><Check className="size-4" />Wybierz</Button>}</div></div>)}{job.status === "assigned" && <Button onClick={onComplete} disabled={busy}><Check className="size-4" />Oznacz jako wykonane</Button>}</div>}{!own && profile?.role === "contractor" && job.status === "open" && !already && <form className="grid gap-4 border-t border-border pt-5" onSubmit={onOffer}><div className="flex items-center justify-between"><h3 className="font-bold">Złóż ofertę</h3><span className="inline-flex items-center gap-1 text-sm font-bold text-primary"><Coins className="size-4" />koszt 10 pkt</span></div><div className="grid gap-4 sm:grid-cols-2"><Field label="Cena"><input name="price" type="number" min={1} required placeholder="800" /></Field><Field label="Czas realizacji (dni)"><input name="days" type="number" min={1} max={365} required placeholder="3" /></Field></div><Field label="Wiadomość do klienta"><textarea name="message" minLength={10} maxLength={1500} rows={4} required placeholder="Opisz doświadczenie i zakres swojej oferty…" /></Field>{notice && <p className="rounded-md bg-muted p-3 text-sm">{notice}</p>}<Button disabled={busy || (profile?.points ?? 0) < 10}>Wyślij ofertę</Button></form>}{already && !own && <p className="rounded-md bg-muted p-4 text-sm font-semibold">Twoja oferta została już wysłana.</p>}{!user && <p className="rounded-md bg-muted p-4 text-sm">Zaloguj się jako wykonawca, aby złożyć ofertę.</p>}{canReview && <form className="grid gap-4 border-t border-border pt-5" onSubmit={onReview}><h3 className="font-bold">Oceń współpracę</h3><Field label="Ocena"><select name="rating" required defaultValue="5"><option value="5">5 — świetnie</option><option value="4">4 — dobrze</option><option value="3">3 — w porządku</option><option value="2">2 — słabo</option><option value="1">1 — źle</option></select></Field><Field label="Opinia"><textarea name="comment" maxLength={1000} rows={3} placeholder="Napisz kilka słów o współpracy…" /></Field>{notice && <p className="rounded-md bg-muted p-3 text-sm">{notice}</p>}<Button disabled={busy}><Star className="size-4" />Dodaj opinię</Button></form>}</div>;
}