import { createFileRoute } from "@tanstack/react-router";
import { ZlecenkaApp } from "@/components/zlecenka-app";

// No head() here: the home route inherits title/description/og/twitter from
// __root.tsx, and ships no og:image so serve-time hosting can inject the
// project's social preview (explicit og:image or latest screenshot).
export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Zlecenka — zlecenia i fachowcy w Twojej okolicy" },
    { name: "description", content: "Dodaj zlecenie, porównaj oferty wykonawców i ustal szczegóły bezpośrednio w Zlecence." },
    { property: "og:title", content: "Zlecenka — lokalne zlecenia i fachowcy" },
    { property: "og:description", content: "Publikuj zlecenia, składaj oferty i rozmawiaj z klientami w jednym miejscu." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: Index,
});

// IMPORTANT: Replace this placeholder. See ./README.md for routing conventions.
function Index() {
  return <ZlecenkaApp />;
}
