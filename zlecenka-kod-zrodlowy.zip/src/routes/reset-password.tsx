import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { KeyRound } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/reset-password")({
  head: () => ({ meta: [
    { title: "Ustaw nowe hasło — Zlecenka" },
    { name: "description", content: "Ustaw nowe hasło do swojego konta Zlecenka." },
    { property: "og:title", content: "Ustaw nowe hasło — Zlecenka" },
    { property: "og:description", content: "Bezpieczne odzyskiwanie dostępu do konta." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary" },
  ] }), component: ResetPassword,
});

function ResetPassword() {
  const [message, setMessage] = useState(""); const [done, setDone] = useState(false); const [recovery, setRecovery] = useState(false);
  useEffect(() => { const params = new URLSearchParams(window.location.hash.slice(1)); setRecovery(params.get("type") === "recovery" || Boolean(params.get("access_token"))); }, []);
  async function submit(e: FormEvent<HTMLFormElement>) { e.preventDefault(); const f = new FormData(e.currentTarget); const password = String(f.get("password") ?? ""); if (password.length < 8) { setMessage("Hasło musi mieć co najmniej 8 znaków."); return; } const { error } = await supabase.auth.updateUser({ password }); setMessage(error ? error.message : "Hasło zostało zmienione."); setDone(!error); }
  return <main className="grid min-h-screen place-items-center bg-muted p-4"><section className="w-full max-w-md rounded-lg border border-border bg-background p-7"><KeyRound className="mb-5 size-9 text-primary" /><h1 className="text-2xl font-black">Ustaw nowe hasło</h1><p className="mt-2 text-sm text-muted-foreground">Wpisz nowe hasło do konta Zlecenka.</p>{!recovery ? <div className="mt-6 grid gap-4"><p className="rounded-md bg-muted p-3 text-sm">Ten link jest nieprawidłowy lub wygasł. Poproś o nowy link na ekranie logowania.</p><Button asChild variant="outline"><Link to="/">Wróć do Zlecenki</Link></Button></div> : !done ? <form className="mt-6 grid gap-4" onSubmit={submit}><label className="grid gap-2 text-sm font-semibold">Nowe hasło<input name="password" type="password" minLength={8} required autoComplete="new-password" /></label>{message && <p className="text-sm">{message}</p>}<Button>Zapisz hasło</Button></form> : <div className="mt-6 grid gap-4"><p className="text-sm text-primary">{message}</p><Button asChild><Link to="/">Wróć do Zlecenki</Link></Button></div>}</section></main>;
}