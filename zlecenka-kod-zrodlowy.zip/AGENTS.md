<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Keep Zlecenka as a single application shell with public marketplace and session-aware workspaces, because shared job context should persist across task, offer, and chat views.
- Enforce point charging and offer selection with database triggers, because balances and accepted offers must remain consistent under concurrent requests.
