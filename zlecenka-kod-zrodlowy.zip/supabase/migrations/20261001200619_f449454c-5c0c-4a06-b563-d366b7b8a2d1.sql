REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM PUBLIC, anon, authenticated;
DROP FUNCTION public.submit_offer(uuid, integer, integer, text);
DROP FUNCTION public.accept_offer(uuid);
REVOKE UPDATE ON public.profiles FROM authenticated;
GRANT UPDATE (role, display_name, avatar_url, bio, location, service_radius, specialties) ON public.profiles TO authenticated;

CREATE OR REPLACE FUNCTION public.charge_new_offer()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE current_points integer;
BEGIN
  IF new.contractor_id <> auth.uid() THEN RAISE EXCEPTION 'Nieprawidłowy wykonawca'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'contractor') THEN RAISE EXCEPTION 'Tylko wykonawca może złożyć ofertę'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.jobs WHERE id = new.job_id AND status = 'open' AND client_id <> auth.uid()) THEN RAISE EXCEPTION 'Zlecenie nie jest dostępne'; END IF;
  SELECT points INTO current_points FROM public.profiles WHERE id = auth.uid() FOR UPDATE;
  IF current_points < 10 THEN RAISE EXCEPTION 'Za mało punktów'; END IF;
  UPDATE public.profiles SET points = points - 10 WHERE id = auth.uid();
  RETURN new;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.charge_new_offer() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER before_offer_created BEFORE INSERT ON public.offers FOR EACH ROW EXECUTE FUNCTION public.charge_new_offer();

CREATE OR REPLACE FUNCTION public.record_offer_charge()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.point_transactions(user_id, offer_id, amount, description) VALUES (new.contractor_id, new.id, -10, 'Złożenie oferty');
  RETURN new;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.record_offer_charge() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER after_offer_created AFTER INSERT ON public.offers FOR EACH ROW EXECUTE FUNCTION public.record_offer_charge();

CREATE OR REPLACE FUNCTION public.sync_selected_offer()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF new.selected_offer_id IS DISTINCT FROM old.selected_offer_id AND new.selected_offer_id IS NOT NULL THEN
    IF new.client_id <> auth.uid() OR NOT EXISTS (SELECT 1 FROM public.offers WHERE id = new.selected_offer_id AND job_id = new.id) THEN RAISE EXCEPTION 'Nie można wybrać tej oferty'; END IF;
    new.status := 'assigned';
    UPDATE public.offers SET status = CASE WHEN id = new.selected_offer_id THEN 'accepted'::public.offer_status ELSE 'rejected'::public.offer_status END WHERE job_id = new.id;
  END IF;
  RETURN new;
END;
$$;
REVOKE EXECUTE ON FUNCTION public.sync_selected_offer() FROM PUBLIC, anon, authenticated;
CREATE TRIGGER before_job_offer_selected BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.sync_selected_offer();

REVOKE EXECUTE ON FUNCTION public.refresh_profile_rating() FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM PUBLIC, anon, authenticated;