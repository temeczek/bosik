CREATE TYPE public.user_kind AS ENUM ('client', 'contractor');
CREATE TYPE public.job_status AS ENUM ('open', 'assigned', 'completed', 'cancelled');
CREATE TYPE public.offer_status AS ENUM ('pending', 'accepted', 'rejected');

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$;

CREATE TABLE public.profiles (
  id uuid PRIMARY KEY,
  role public.user_kind NOT NULL DEFAULT 'client',
  display_name text NOT NULL DEFAULT 'Nowy użytkownik' CHECK (char_length(display_name) BETWEEN 2 AND 80),
  avatar_url text,
  bio text CHECK (bio IS NULL OR char_length(bio) <= 800),
  location text CHECK (location IS NULL OR char_length(location) <= 120),
  service_radius integer NOT NULL DEFAULT 25 CHECK (service_radius BETWEEN 1 AND 200),
  specialties text[] NOT NULL DEFAULT '{}',
  points integer NOT NULL DEFAULT 0 CHECK (points >= 0),
  rating numeric(2,1) NOT NULL DEFAULT 0 CHECK (rating BETWEEN 0 AND 5),
  review_count integer NOT NULL DEFAULT 0 CHECK (review_count >= 0),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT ON public.profiles TO anon, authenticated;
GRANT INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles_public_read" ON public.profiles FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "profiles_own_insert" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);
CREATE POLICY "profiles_own_update" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

CREATE TABLE public.jobs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  title text NOT NULL CHECK (char_length(title) BETWEEN 5 AND 120),
  category text NOT NULL CHECK (char_length(category) BETWEEN 2 AND 60),
  description text NOT NULL CHECK (char_length(description) BETWEEN 20 AND 3000),
  location text NOT NULL CHECK (char_length(location) BETWEEN 2 AND 120),
  due_date date,
  budget_min integer CHECK (budget_min IS NULL OR budget_min >= 0),
  budget_max integer CHECK (budget_max IS NULL OR budget_max >= 0),
  images text[] NOT NULL DEFAULT '{}',
  status public.job_status NOT NULL DEFAULT 'open',
  selected_offer_id uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CHECK (budget_min IS NULL OR budget_max IS NULL OR budget_max >= budget_min)
);
GRANT SELECT ON public.jobs TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.jobs TO authenticated;
GRANT ALL ON public.jobs TO service_role;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "jobs_public_open_read" ON public.jobs FOR SELECT TO anon USING (status = 'open');
CREATE POLICY "jobs_authenticated_read" ON public.jobs FOR SELECT TO authenticated USING (status = 'open' OR client_id = auth.uid());
CREATE POLICY "jobs_own_insert" ON public.jobs FOR INSERT TO authenticated WITH CHECK (client_id = auth.uid());
CREATE POLICY "jobs_own_update" ON public.jobs FOR UPDATE TO authenticated USING (client_id = auth.uid()) WITH CHECK (client_id = auth.uid());
CREATE POLICY "jobs_own_delete" ON public.jobs FOR DELETE TO authenticated USING (client_id = auth.uid() AND status = 'open');

CREATE TABLE public.offers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  contractor_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  price integer NOT NULL CHECK (price >= 0),
  completion_days integer NOT NULL CHECK (completion_days BETWEEN 1 AND 365),
  message text NOT NULL CHECK (char_length(message) BETWEEN 10 AND 1500),
  status public.offer_status NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id, contractor_id)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.offers TO authenticated;
GRANT ALL ON public.offers TO service_role;
ALTER TABLE public.offers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "offers_participant_read" ON public.offers FOR SELECT TO authenticated USING (contractor_id = auth.uid() OR EXISTS (SELECT 1 FROM public.jobs j WHERE j.id = job_id AND j.client_id = auth.uid()));
CREATE POLICY "offers_contractor_insert" ON public.offers FOR INSERT TO authenticated WITH CHECK (contractor_id = auth.uid());
CREATE POLICY "offers_contractor_update" ON public.offers FOR UPDATE TO authenticated USING (contractor_id = auth.uid()) WITH CHECK (contractor_id = auth.uid());
CREATE POLICY "offers_contractor_delete" ON public.offers FOR DELETE TO authenticated USING (contractor_id = auth.uid() AND status = 'pending');

ALTER TABLE public.jobs ADD CONSTRAINT jobs_selected_offer_fk FOREIGN KEY (selected_offer_id) REFERENCES public.offers(id) ON DELETE SET NULL;

CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  offer_id uuid NOT NULL REFERENCES public.offers(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 2000),
  read_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages_participant_read" ON public.messages FOR SELECT TO authenticated USING (EXISTS (SELECT 1 FROM public.offers o JOIN public.jobs j ON j.id = o.job_id WHERE o.id = offer_id AND (o.contractor_id = auth.uid() OR j.client_id = auth.uid())));
CREATE POLICY "messages_participant_insert" ON public.messages FOR INSERT TO authenticated WITH CHECK (sender_id = auth.uid() AND EXISTS (SELECT 1 FROM public.offers o JOIN public.jobs j ON j.id = o.job_id WHERE o.id = offer_id AND (o.contractor_id = auth.uid() OR j.client_id = auth.uid())));
CREATE POLICY "messages_recipient_update" ON public.messages FOR UPDATE TO authenticated USING (sender_id <> auth.uid() AND EXISTS (SELECT 1 FROM public.offers o JOIN public.jobs j ON j.id = o.job_id WHERE o.id = offer_id AND (o.contractor_id = auth.uid() OR j.client_id = auth.uid())));

CREATE TABLE public.point_transactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  offer_id uuid REFERENCES public.offers(id) ON DELETE SET NULL,
  amount integer NOT NULL CHECK (amount <> 0),
  description text NOT NULL CHECK (char_length(description) BETWEEN 2 AND 160),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(offer_id)
);
GRANT SELECT ON public.point_transactions TO authenticated;
GRANT ALL ON public.point_transactions TO service_role;
ALTER TABLE public.point_transactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "point_transactions_own_read" ON public.point_transactions FOR SELECT TO authenticated USING (user_id = auth.uid());

CREATE TABLE public.reviews (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  job_id uuid NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
  author_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  recipient_id uuid NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  rating integer NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment text CHECK (comment IS NULL OR char_length(comment) <= 1000),
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(job_id, author_id),
  CHECK (author_id <> recipient_id)
);
GRANT SELECT ON public.reviews TO anon, authenticated;
GRANT INSERT ON public.reviews TO authenticated;
GRANT ALL ON public.reviews TO service_role;
ALTER TABLE public.reviews ENABLE ROW LEVEL SECURITY;
CREATE POLICY "reviews_public_read" ON public.reviews FOR SELECT TO anon, authenticated USING (true);
CREATE POLICY "reviews_participant_insert" ON public.reviews FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid() AND EXISTS (SELECT 1 FROM public.jobs j JOIN public.offers o ON o.id = j.selected_offer_id WHERE j.id = job_id AND j.status = 'completed' AND recipient_id IN (j.client_id, o.contractor_id) AND author_id IN (j.client_id, o.contractor_id)));

CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE user_role public.user_kind; start_points integer;
BEGIN
  user_role := CASE WHEN new.raw_user_meta_data->>'role' = 'contractor' THEN 'contractor'::public.user_kind ELSE 'client'::public.user_kind END;
  start_points := CASE WHEN user_role = 'contractor' THEN 100 ELSE 0 END;
  INSERT INTO public.profiles (id, role, display_name, points)
  VALUES (new.id, user_role, COALESCE(NULLIF(trim(new.raw_user_meta_data->>'display_name'), ''), split_part(new.email, '@', 1)), start_points);
  IF start_points > 0 THEN
    INSERT INTO public.point_transactions (user_id, amount, description) VALUES (new.id, start_points, 'Pakiet startowy');
  END IF;
  RETURN new;
END;
$$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

CREATE OR REPLACE FUNCTION public.submit_offer(p_job_id uuid, p_price integer, p_completion_days integer, p_message text)
RETURNS public.offers LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE result public.offers; current_points integer;
BEGIN
  IF auth.uid() IS NULL THEN RAISE EXCEPTION 'Brak autoryzacji'; END IF;
  IF p_price < 0 OR p_completion_days < 1 OR p_completion_days > 365 OR char_length(trim(p_message)) < 10 THEN RAISE EXCEPTION 'Nieprawidłowe dane oferty'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'contractor') THEN RAISE EXCEPTION 'Tylko wykonawca może złożyć ofertę'; END IF;
  IF NOT EXISTS (SELECT 1 FROM public.jobs WHERE id = p_job_id AND status = 'open' AND client_id <> auth.uid()) THEN RAISE EXCEPTION 'Zlecenie nie jest dostępne'; END IF;
  SELECT points INTO current_points FROM public.profiles WHERE id = auth.uid() FOR UPDATE;
  IF current_points < 10 THEN RAISE EXCEPTION 'Za mało punktów'; END IF;
  INSERT INTO public.offers(job_id, contractor_id, price, completion_days, message) VALUES (p_job_id, auth.uid(), p_price, p_completion_days, trim(p_message)) RETURNING * INTO result;
  UPDATE public.profiles SET points = points - 10 WHERE id = auth.uid();
  INSERT INTO public.point_transactions(user_id, offer_id, amount, description) VALUES (auth.uid(), result.id, -10, 'Złożenie oferty');
  RETURN result;
END;
$$;
GRANT EXECUTE ON FUNCTION public.submit_offer(uuid, integer, integer, text) TO authenticated;

CREATE OR REPLACE FUNCTION public.accept_offer(p_offer_id uuid)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE target_job uuid;
BEGIN
  SELECT o.job_id INTO target_job FROM public.offers o JOIN public.jobs j ON j.id = o.job_id WHERE o.id = p_offer_id AND j.client_id = auth.uid() AND j.status = 'open' FOR UPDATE;
  IF target_job IS NULL THEN RAISE EXCEPTION 'Nie można wybrać tej oferty'; END IF;
  UPDATE public.offers SET status = CASE WHEN id = p_offer_id THEN 'accepted'::public.offer_status ELSE 'rejected'::public.offer_status END WHERE job_id = target_job;
  UPDATE public.jobs SET status = 'assigned', selected_offer_id = p_offer_id WHERE id = target_job;
END;
$$;
GRANT EXECUTE ON FUNCTION public.accept_offer(uuid) TO authenticated;

CREATE OR REPLACE FUNCTION public.refresh_profile_rating()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  UPDATE public.profiles SET rating = COALESCE((SELECT round(avg(rating)::numeric, 1) FROM public.reviews WHERE recipient_id = new.recipient_id), 0), review_count = (SELECT count(*) FROM public.reviews WHERE recipient_id = new.recipient_id) WHERE id = new.recipient_id;
  RETURN new;
END;
$$;
CREATE TRIGGER on_review_created AFTER INSERT ON public.reviews FOR EACH ROW EXECUTE FUNCTION public.refresh_profile_rating();

CREATE TRIGGER profiles_updated BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER jobs_updated BEFORE UPDATE ON public.jobs FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE TRIGGER offers_updated BEFORE UPDATE ON public.offers FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
CREATE INDEX jobs_status_created_idx ON public.jobs(status, created_at DESC);
CREATE INDEX jobs_category_location_idx ON public.jobs(category, location);
CREATE INDEX offers_job_idx ON public.offers(job_id);
CREATE INDEX messages_offer_created_idx ON public.messages(offer_id, created_at);
ALTER PUBLICATION supabase_realtime ADD TABLE public.messages;