# Roadmap
- [x] Włączyć Lovable Cloud i przygotować bezpieczny model danych.
- [x] Dodać konta, pełne profile i odzyskiwanie hasła.
- [x] Dodać publikowanie i przeglądanie zleceń z filtrami.
- [x] Dodać oferty płatne punktami i saldo startowe.
- [x] Dodać czat, wybór wykonawcy, statusy i opinie.
- [ ] Zweryfikować cały przepływ oraz widoki mobilne i komputerowe.
